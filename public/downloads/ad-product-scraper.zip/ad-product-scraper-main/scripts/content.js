const body = document.body;

const scrap = document.createElement("details");
scrap.classList.add("scrap-wrapper");
scrap.innerHTML = '<summary class="heading">Product Scrapper</summary>';

const scrapContent = document.createElement("div");
scrapContent.classList.add("scrap-content");

let content = '';

// oe numbers
let oeNumbers = [];
let oeElements = document.querySelectorAll('.product-oem__list li');

oeElements.forEach(element => {
    let href = element.querySelector('a')?.getAttribute('href');

    if(href){
        let parts = href.split('/');

        if(parts.length > 0){
            oeNumbers.push(parts[parts.length - 1]);
        }
    }
});

// tutorials

let pdfs = '';
let pdfElements = document.querySelectorAll('.pdf-list-item__content')
pdfElements.forEach(function(el){
    pdfs += `<p>
        <a target="_blank" href="${el.lastElementChild.getAttribute('url')}">${el.firstElementChild.innerText}</a>
    </p>`
});

content += `<p class="title"><b>PDFs <i>(click to download)</i>: </b> ${pdfs}</p>`;


let json = {};

json['title'] = getElementValue('.product-block__title')
json['sub_title'] = getElementValue('.product-block__seo-subtitle-text')
json['article_no'] = getElementValue('.product-block__article')
json['attributes'] = [];
json['oe_numbers'] = oeNumbers.join(',');

let attrHTML = '';
let attributes = document.querySelectorAll('.product-description__list li');
attributes.forEach(function(el){
    let key = el.querySelector('span.product-description__item-title').innerText
    let value = el.querySelector('span.product-description__item-value').innerText;
    json['attributes'].push({
        [key]: value
    });

    attrHTML += `
    <tr>
        <td>${key}</td>
        <td>${value}</td>
    </tr>
    `
});

const productContent = document.createElement("div");
productContent.classList.add("content");

let contentHTML = '';
contentHTML = `
<h4>${json['title']}</h4>
<p>${json['sub_title']}</p>
<p>${json['article_no']}</p>
<p  style="margin-bottom:8px;">${json['article_no']}</p>
<table>
<tbody>
    ${attrHTML}
</tbody>
</table>
<br/>
`;

productContent.innerHTML = contentHTML;

scrap.appendChild(productContent)


// DOwnload button
const downloadButton = document.createElement('button');
downloadButton.innerText = 'Download JSON';
downloadButton.addEventListener('click', download);

scrap.appendChild(downloadButton);

scrapContent.innerHTML = content;
scrap.appendChild(scrapContent);

body.appendChild(scrap);

function download(){
    // Create element with <a> tag
    const link = document.createElement("a");

    // Create a blog object with the file content which you want to add to the file
    const file = new Blob([JSON.stringify(json)], { type: 'text/plain' });

    // Add file content in the object URL
    link.href = URL.createObjectURL(file);

    // Add file name
    link.download = getProductId() + '-' + string_to_slug(json['title']) + '.json'

    // Add click event to <a> tag to save file.
    link.click();
    URL.revokeObjectURL(link.href);
}


function getElementText(selector, name){
    let element = document.body.querySelector(selector);

    if( ! element){
        return null;
    }

    return `<p><b>${name}: </b> ${element.innerText}</p>`;
}

function getElementValue(selector){
    let element = document.body.querySelector(selector);

    if( ! element){
        return null;
    }

    return element.innerText;
}

function getElement(selector){
    let element = document.body.querySelector(selector);

    element.querySelector('.about-filter-image')?.remove();

    if( ! element){
        return null;
    }

    return element.innerHTML;
}

function getProductId(){
    urlParts = window.location.href.split('/')
    return urlParts[urlParts.length - 1]
}

function string_to_slug (str) {
    str = str.replace(/^\s+|\s+$/g, ''); // trim
    str = str.toLowerCase();
  
    // remove accents, swap ñ for n, etc
    var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
    var to   = "aaaaeeeeiiiioooouuuunc------";
    for (var i=0, l=from.length ; i<l ; i++) {
        str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
    }

    str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
        .replace(/\s+/g, '-') // collapse whitespace and replace by -
        .replace(/-+/g, '-'); // collapse dashes

    return str;
}